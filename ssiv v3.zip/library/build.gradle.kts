plugins {
    id("com.android.library")
    id("kotlin-android")
    id("kotlin-parcelize")
    id("maven-publish")
}

group = "com.davemorrissey.labs"
version = "4.3.1"

base {
    archivesName.set("subsampling-scale-image-view-androidx")
}

android {
    compileSdk = 35
    namespace = "com.davemorrissey.labs.subscaleview"

    // This must be INSIDE the android block
    publishing {
        singleVariant("release")
    }

    defaultConfig {
        minSdk = 23
        targetSdk = 35
        consumerProguardFiles("proguard-rules.txt")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
        freeCompilerArgs += "-Xexplicit-api=warning"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    defaultConfig {
        externalNativeBuild {
            cmake {
                // arm64-v8a: modern 64-bit Android (NEON SIMD enabled)
                // armeabi-v7a: 32-bit ARM fallback
                // x86_64: emulator support
                abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
            }
        }
    }
} // This brace correctly closes the android block

val javadocs by configurations.creating

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.3.20")
    implementation("androidx.customview:customview:1.2.0")
    javadocs("androidx.annotation:annotation:1.10.0")
    javadocs("androidx.exifinterface:exifinterface:1.4.2")
    implementation("androidx.annotation:annotation:1.10.0")
    implementation("androidx.exifinterface:exifinterface:1.4.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.10.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.11.0")
}

afterEvaluate {
    publishing {
        publications {
            create<MavenPublication>("release") {
                from(components["release"])
                groupId = "com.github.Ero-gamer"
                artifactId = "subsampling-scale-image-view-androidx"
                version = "4.3.1"
            }
        }
    }
}

// Cleaned up Javadoc task to prevent "Unexpected input" errors
tasks.register<Javadoc>("javadoc") {
    isFailOnError = false
    source = android.sourceSets.getByName("main").java.sourceFiles
    classpath += project.files(android.bootClasspath.joinToString(File.pathSeparator))
}
