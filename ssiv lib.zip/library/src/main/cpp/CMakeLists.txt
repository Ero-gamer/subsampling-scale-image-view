cmake_minimum_required(VERSION 3.22)
project(ssiv_jpeg_decoder)

include(ExternalProject)

# A missing/failed SIMD setup must fail the build instead of silently producing the slow scalar
# library (libjpeg-turbo otherwise falls back without a word). Only arm64-v8a / armeabi-v7a are built.
set(LJPEG_REQUIRE_SIMD "-DREQUIRE_SIMD=1")

# ── libjpeg-turbo 3.2.1 ────────────────────────────────────────────────────
# FetchContent / add_subdirectory() are explicitly blocked by libjpeg-turbo's
# own CMakeLists.txt. ExternalProject_Add builds it in a fully isolated
# sub-build so it never gets included as a subdirectory.
set(LJPEG_PREFIX      "${CMAKE_BINARY_DIR}/ljt")
set(LJPEG_INSTALL_DIR "${LJPEG_PREFIX}/install")
set(LJPEG_INCLUDE_DIR "${LJPEG_INSTALL_DIR}/include")
set(LJPEG_LIB         "${LJPEG_INSTALL_DIR}/lib/libturbojpeg.a")

ExternalProject_Add(libjpeg_turbo_ext
    PREFIX      "${LJPEG_PREFIX}"
    URL         https://github.com/libjpeg-turbo/libjpeg-turbo/releases/download/3.2.1/libjpeg-turbo-3.2.1.tar.gz
    URL_HASH    SHA256=c27ad72a68da151177929aa969ae773a2da5ac2af9ce946079314fdac8cece7f

    CMAKE_ARGS
        # Android cross-compilation — forward every variable AGP passes to us
        -DCMAKE_TOOLCHAIN_FILE=${CMAKE_TOOLCHAIN_FILE}
        -DCMAKE_SYSTEM_NAME=Android
        -DCMAKE_SYSTEM_VERSION=${ANDROID_PLATFORM}
        -DANDROID_ABI=${ANDROID_ABI}
        -DANDROID_PLATFORM=${ANDROID_PLATFORM}
        -DANDROID_NDK=${ANDROID_NDK}
        -DCMAKE_ANDROID_ARCH_ABI=${ANDROID_ABI}
        -DCMAKE_ANDROID_NDK=${CMAKE_ANDROID_NDK}
        -DCMAKE_MAKE_PROGRAM=${CMAKE_MAKE_PROGRAM}
        -DCMAKE_BUILD_TYPE=${CMAKE_BUILD_TYPE}
        # Only build what we need
        -DENABLE_SHARED=OFF
        -DENABLE_STATIC=ON
        -DWITH_SIMD=ON
        ${LJPEG_REQUIRE_SIMD}
        -DWITH_TURBOJPEG=ON
        -DWITH_JAVA=OFF
        -DWITH_JPEG8=ON
        -DCMAKE_INSTALL_PREFIX=${LJPEG_INSTALL_DIR}

    # Tell Ninja about the output so it knows this target produces the .a file
    BUILD_BYPRODUCTS "${LJPEG_LIB}"

    # Use cmake --install (works regardless of generator — Ninja or Make)
    INSTALL_COMMAND
        ${CMAKE_COMMAND} --install "${LJPEG_PREFIX}/src/libjpeg_turbo_ext-build"
            --prefix "${LJPEG_INSTALL_DIR}"

    TEST_COMMAND ""
)

# Import the static library as a CMake target so our JNI lib can link it
add_library(turbojpeg_static STATIC IMPORTED GLOBAL)
add_dependencies(turbojpeg_static libjpeg_turbo_ext)
set_target_properties(turbojpeg_static PROPERTIES
    IMPORTED_LOCATION "${LJPEG_LIB}"
)

# Create the include dir at configure time so target_include_directories
# doesn't fail because the directory doesn't exist yet (it is created at build time)
file(MAKE_DIRECTORY "${LJPEG_INCLUDE_DIR}")

# ── JNI bridge ────────────────────────────────────────────────────────────────
add_library(ssiv_jpeg_decoder SHARED jpeg_jni.cpp jpeg_core.cpp)

add_dependencies(ssiv_jpeg_decoder libjpeg_turbo_ext)

target_include_directories(ssiv_jpeg_decoder PRIVATE "${LJPEG_INCLUDE_DIR}")

target_link_libraries(ssiv_jpeg_decoder
    turbojpeg_static
    jnigraphics
    android
    log
)

# 16 KB page-size compatible ELF segments (Android 15+ devices), smaller and faster-loading library.
target_compile_options(ssiv_jpeg_decoder PRIVATE -O2 -fvisibility=hidden -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti)

# Thin LTO for release builds when the toolchain supports it.
include(CheckIPOSupported)
check_ipo_supported(RESULT ssiv_ipo_ok OUTPUT ssiv_ipo_msg LANGUAGES C CXX)
if(ssiv_ipo_ok AND CMAKE_BUILD_TYPE STREQUAL "Release")
    set_property(TARGET ssiv_jpeg_decoder PROPERTY INTERPROCEDURAL_OPTIMIZATION TRUE)
endif()
# --exclude-libs hides the static libjpeg-turbo symbols; --icf=safe folds identical code (lld, NDK default).
target_link_options(ssiv_jpeg_decoder PRIVATE
    -Wl,-z,max-page-size=16384
    -Wl,--gc-sections
    -Wl,--exclude-libs,ALL
    -Wl,--icf=safe
)
