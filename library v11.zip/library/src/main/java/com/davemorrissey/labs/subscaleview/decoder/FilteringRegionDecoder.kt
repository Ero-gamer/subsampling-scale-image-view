package com.davemorrissey.labs.subscaleview.decoder

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Point
import android.graphics.Rect
import android.net.Uri
import androidx.annotation.WorkerThread
import com.davemorrissey.labs.subscaleview.ImageSource
import kotlin.math.abs
import kotlin.random.Random

/**
 * [ImageRegionDecoder] wrapper that applies CPU denoise, sharpening, vibrance, dithering and
 * grain to every decoded tile immediately after the inner decoder returns it — all in ONE
 * getPixels -> loop -> setPixels pass (no extra buffers/allocations beyond the two pooled
 * IntArrays already used for sharpening).
 *
 * Pipeline order per pixel: denoise -> sharpen -> vibrance -> dither+grain. Denoise always runs
 * whenever sharpening is enabled (it exists specifically to stop the Laplacian sharpen from
 * amplifying JPEG-block/compression noise) — there's no separate toggle for it. Dither+grain
 * always run whenever this pass runs at all (denoise/sharpen/vibrance active), since their whole
 * purpose is smoothing out banding this pass's own float->int rounding can introduce; they add
 * no extra pixel reads (same neighbours already fetched for sharpen) beyond dither/grain's own
 * tiny lookup-table add.
 *
 * The filter math is identical to [org.koitharu.kotatsu.core.ui.image.ImageFiltersTransformation]
 * (which is kept for the ColorFilterConfigActivity preview and any non-SSIV callers) — keep
 * both in sync when changing constants here.
 */
public class FilteringRegionDecoder(
    private val inner: ImageRegionDecoder,
    private val sharpening: Float,
    private val vibrance: Float,
) : ImageRegionDecoder {

    override fun init(context: Context, uri: Uri): Point = inner.init(context, uri)

    override fun init(context: Context, source: ImageSource): Point = inner.init(context, source)

    @WorkerThread
    override fun decodeRegion(sRect: Rect, sampleSize: Int): Bitmap {
        val tile = inner.decodeRegion(sRect, sampleSize)
        // Defensive: any unexpected failure in the filter math (OOM on getPixels/setPixels
        // arrays, unsupported bitmap state, etc) must not throw out of decodeRegion — SSIV
        // swallows such throws into a no-op onTileLoadError and never retries, permanently
        // leaving that region unfilled/unfiltered. Falling back to the already-decoded,
        // unfiltered tile keeps the page readable and self-corrects the moment filters
        // legitimately apply again (next reload), instead of a silent permanent failure.
        return try {
            applyFilters(tile)
        } catch (e: Throwable) {
            tile
        }
    }

    override val isReady: Boolean
        get() = inner.isReady

    override fun recycle() = inner.recycle()

    // ── filter math ──────────────────────────────────────────────────────────

    private fun applyFilters(tile: Bitmap): Bitmap {
        val doSharpen = sharpening > 0.01f
        val doVibrance = vibrance != 0f
        if (!doSharpen && !doVibrance) return tile

        val w = tile.width
        val h = tile.height
        if (w <= 0 || h <= 0) return tile

        val needsCopy = tile.config != Bitmap.Config.ARGB_8888 || !tile.isMutable
        // BUG FIX (silent-unfiltered-image): Bitmap.copy() is a platform type that CAN return
        // null (allocation failure, unsupported config conversion for a malformed/atypical
        // source image). The original never-recycle-until-success ordering below is what makes
        // that survivable — see the second bug fix note further down for what happens if
        // something throws mid-pass.
        val working = if (needsCopy) tile.copy(Bitmap.Config.ARGB_8888, true) ?: tile else tile

        val pixelCount = w * h
        val src = srcPool.acquire(pixelCount)
        working.getPixels(src, 0, w, 0, 0, w, h)

        val k = if (doSharpen) kernelStrength(sharpening) else 0f
        // Sharpening (and denoise, which feeds it) read src while writing to out to avoid
        // corrupting neighbour pixels mid-pass.
        val out = if (doSharpen) outPool.acquire(pixelCount) else src

        for (y in 0 until h) {
            val rowStart = y * w
            val hasAbove = y > 0
            val hasBelow = y < h - 1
            val rowNoise = DITHER_GRAIN
            for (x in 0 until w) {
                val idx = rowStart + x
                val px = src[idx]
                var r: Int
                var g: Int
                var b: Int

                if (doSharpen && x > 0 && x < w - 1 && hasAbove && hasBelow) {
                    val top    = src[idx - w]
                    val bottom = src[idx + w]
                    val left   = src[idx - 1]
                    val right  = src[idx + 1]
                    val tr = (top shr 16) and 0xFF;    val tg = (top shr 8) and 0xFF;    val tb = top and 0xFF
                    val brr = (bottom shr 16) and 0xFF; val bg = (bottom shr 8) and 0xFF; val bb = bottom and 0xFF
                    val lr = (left shr 16) and 0xFF;   val lg = (left shr 8) and 0xFF;   val lb = left and 0xFF
                    val rr = (right shr 16) and 0xFF;  val rg = (right shr 8) and 0xFF;  val rb = right and 0xFF
                    val cr = (px shr 16) and 0xFF; val cg = (px shr 8) and 0xFF; val cb = px and 0xFF

                    // Denoise always precedes sharpen when sharpening is active: an edge-aware
                    // (bilateral-lite) blend of center+neighbours replaces the center value fed
                    // into the Laplacian below, so the sharpen kernel amplifies real edges
                    // instead of amplifying JPEG-block/compression noise along with them.
                    val dr = denoiseChannel(cr, tr, brr, lr, rr)
                    val dg = denoiseChannel(cg, tg, bg, lg, rg)
                    val db = denoiseChannel(cb, tb, bb, lb, rb)

                    r = sharpenChannel(dr, tr, brr, lr, rr, k)
                    g = sharpenChannel(dg, tg, bg, lg, rg, k)
                    b = sharpenChannel(db, tb, bb, lb, rb, k)
                } else {
                    r = (px shr 16) and 0xFF
                    g = (px shr 8) and 0xFF
                    b = px and 0xFF
                }

                if (doVibrance) {
                    val factor = vibranceFactor(r, g, b, vibrance)
                    if (factor != 1f) {
                        val mean = (r + g + b) / 3f
                        r = clamp255(mean + (r - mean) * factor)
                        g = clamp255(mean + (g - mean) * factor)
                        b = clamp255(mean + (b - mean) * factor)
                    }
                }

                // Dither+grain: tiny luma-only perturbation (same delta on r/g/b, so no chroma
                // speckle) from a precomputed table combining an 8x8 ordered-dither pattern
                // (breaks up banding from this pass's own float->int rounding above) with light
                // random grain. Table is indexed by in-tile position, not absolute page position
                // — a 1px seam in the noise pattern at tile boundaries is imperceptible for
                // noise, and avoiding absolute coordinates keeps this pass allocation-free.
                val noise = rowNoise[((y and 63) shl 6) or (x and 63)]
                if (noise != 0) {
                    r = (r + noise).coerceIn(0, 255)
                    g = (g + noise).coerceIn(0, 255)
                    b = (b + noise).coerceIn(0, 255)
                }

                out[idx] = (px and ALPHA_MASK) or (r shl 16) or (g shl 8) or b
            }
        }

        working.setPixels(out, 0, w, 0, 0, w, h)
        // BUG FIX (recycled-bitmap-on-error): recycle the ORIGINAL only now, after every step
        // that could throw (getPixels/setPixels/OOM in the pools) has already succeeded. The
        // previous version recycled `tile` immediately after the copy, before the pixel loop
        // ran — if anything below it threw, decodeRegion()'s catch block returned `tile`
        // (the same object, by reference) already recycled, which crashes the next time SSIV
        // tries to draw it. Deferring recycle to here means the catch-all fallback always
        // returns a live bitmap.
        if (needsCopy && working !== tile) tile.recycle()
        return working
    }

    // ── denoise ──────────────────────────────────────────────────────────────

    /**
     * Edge-aware ("bilateral-lite") denoise for one channel: blends [center] toward its 4
     * neighbours, weighting each neighbour DOWN the more it differs from center — this avoids
     * blurring across real edges (which a plain box blur would do) while still smoothing flat
     * noisy regions where neighbours are already close to center. [DENOISE_STRENGTH] caps how
     * far center is allowed to move.
     */
    private fun denoiseChannel(center: Int, top: Int, bottom: Int, left: Int, right: Int): Int {
        val wT = 1f / (1f + abs(center - top) * DENOISE_RANGE_FALLOFF)
        val wB = 1f / (1f + abs(center - bottom) * DENOISE_RANGE_FALLOFF)
        val wL = 1f / (1f + abs(center - left) * DENOISE_RANGE_FALLOFF)
        val wR = 1f / (1f + abs(center - right) * DENOISE_RANGE_FALLOFF)
        val wSum = 1f + wT + wB + wL + wR
        val denoised = (center + top * wT + bottom * wB + left * wL + right * wR) / wSum
        return clamp255(center + DENOISE_STRENGTH * (denoised - center))
    }

    // ── sharpening ───────────────────────────────────────────────────────────

    /** Maps the 0..1 slider to Laplacian kernel strength k (0..0.5). */
    private fun kernelStrength(amount: Float): Float =
        amount.coerceIn(0f, 1f) * SHARPEN_SCALAR

    /** Standard 5-point discrete Laplacian sharpen for one channel (0..255). */
    private fun sharpenChannel(
        center: Int, top: Int, bottom: Int, left: Int, right: Int, k: Float,
    ): Int {
        val v = center + k * (4 * center - top - bottom - left - right)
        return when {
            v <= 0f   -> 0
            v >= 255f -> 255
            else      -> (v + 0.5f).toInt()
        }
    }

    // ── vibrance ─────────────────────────────────────────────────────────────

    /**
     * Selective vibrance factor for a pixel with channels [r]/[g]/[b] (0..255).
     * Returns a multiplier to apply to (channel - mean); 1f = no change.
     * Dull/muted pixels (low HSL saturation) receive the most boost.
     */
    private fun vibranceFactor(r: Int, g: Int, b: Int, v: Float): Float {
        if (v == 0f) return 1f
        val maxC = maxOf(r, g, b)
        val minC = minOf(r, g, b)
        val delta = maxC - minC
        if (delta == 0) return 1f

        val lSum = maxC + minC
        val denom = (if (lSum <= 255) lSum else 510 - lSum).coerceAtLeast(1)
        val sat = delta.toFloat() / denom
        val selectivity = (1f - sat) * (1f - sat)
        return 1f + v.coerceIn(-1f, 1f) * selectivity * VIBRANCE_SCALAR
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    private fun clamp255(v: Float): Int = when {
        v <= 0f   -> 0
        v >= 255f -> 255
        else      -> (v + 0.5f).toInt()
    }

    // ── Factory ──────────────────────────────────────────────────────────────

    /**
     * Produces [FilteringRegionDecoder] instances wrapping decoders from [innerFactory].
     *
     * [bitmapConfig] is forwarded from [innerFactory] so that [ReaderSettings.applyBitmapConfig]
     * can compare configs correctly via [DecoderFactory.bitmapConfig].
     *
     * [sharpening] and [vibrance] are stored on the factory so that a change in filter
     * params is detected in [ReaderSettings.applyBitmapConfig] by comparing factory instances,
     * which triggers [SubsamplingScaleImageView.setImage] with the new factory installed.
     */
    public class Factory(
        private val innerFactory: DecoderFactory<out ImageRegionDecoder>,
        val sharpening: Float,
        val vibrance: Float,
    ) : DecoderFactory<FilteringRegionDecoder> {

        override val bitmapConfig: Bitmap.Config?
            get() = innerFactory.bitmapConfig

        override fun make(): FilteringRegionDecoder =
            FilteringRegionDecoder(innerFactory.make(), sharpening, vibrance)
    }

    // ── pixel buffer pool ─────────────────────────────────────────────────────

    /**
     * Thread-local pools for the src and out pixel arrays used by [applyFilters].
     *
     * SSIV dispatches tile decodes on [Dispatchers.Default] (shared thread pool, typically
     * CPU-count threads). Each thread reuses the same IntArray across tiles, eliminating
     * the 1–2 × w*h × 4-byte allocations and subsequent GC pauses that caused jank during
     * fast webtoon scroll on low-RAM / Cortex-A53 devices.
     *
     * Arrays grow on demand (coerced to a power-of-two capacity for alignment) and are
     * never shrunk — the largest tile seen by a thread defines its steady-state allocation.
     * On a 1080px-wide strip with 512px tiles that is one allocation of ~2 MB per thread,
     * amortised over thousands of tile decodes.
     */
    private companion object {
        private const val SHARPEN_SCALAR  = 0.5f
        private const val VIBRANCE_SCALAR = 1.5f
        private const val DENOISE_STRENGTH = 0.6f
        private const val DENOISE_RANGE_FALLOFF = 0.15f
        private val ALPHA_MASK = 0xFF000000.toInt()

        // Two pools: src (always needed) and out (only when sharpening, because sharpening
        // must read from src while writing to out to avoid corrupting neighbour pixels).
        private val srcPool = ThreadLocal<IntArray>()
        private val outPool = ThreadLocal<IntArray>()

        /** Returns a thread-local array of at least [minSize] ints, growing if necessary. */
        private fun ThreadLocal<IntArray>.acquire(minSize: Int): IntArray {
            val existing = get()
            if (existing != null && existing.size >= minSize) return existing
            // Round up to next power of two to reduce reallocations on incrementally larger tiles.
            var cap = minSize.coerceAtLeast(1024)
            cap = Integer.highestOneBit(cap - 1) shl 1
            val arr = IntArray(cap)
            set(arr)
            return arr
        }

        /**
         * 64x64 precomputed dither+grain table, generated once (deterministic seed).
         * Combines an 8x8 ordered (Bayer) dither pattern, tiled 8x, with light random grain —
         * see [buildDitherGrainTable]. Values are small signed ints (~ -5..+5).
         */
        private val DITHER_GRAIN: IntArray = buildDitherGrainTable()

        private fun buildDitherGrainTable(): IntArray {
            val bayer8 = intArrayOf(
                0, 32, 8, 40, 2, 34, 10, 42,
                48, 16, 56, 24, 50, 18, 58, 26,
                12, 44, 4, 36, 14, 46, 6, 38,
                60, 28, 52, 20, 62, 30, 54, 22,
                3, 35, 11, 43, 1, 33, 9, 41,
                51, 19, 59, 27, 49, 17, 57, 25,
                15, 47, 7, 39, 13, 45, 5, 37,
                63, 31, 55, 23, 61, 29, 53, 21,
            )
            val random = Random(0xC0FFEE)
            val table = IntArray(64 * 64)
            for (y in 0 until 64) {
                for (x in 0 until 64) {
                    val bayerValue = bayer8[(y % 8) * 8 + (x % 8)] // 0..63
                    val ditherBias = (bayerValue / 63f - 0.5f) * DITHER_AMPLITUDE
                    val grainBias = (random.nextFloat() - 0.5f) * GRAIN_AMPLITUDE
                    table[y * 64 + x] = (ditherBias + grainBias).let {
                        when {
                            it <= -8f -> -8
                            it >= 8f  -> 8
                            else      -> Math.round(it)
                        }
                    }
                }
            }
            return table
        }

        private const val DITHER_AMPLITUDE = 3f
        private const val GRAIN_AMPLITUDE = 5f
    }
}
